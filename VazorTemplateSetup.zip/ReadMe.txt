1. Run the VazorTemplateSetup.vsix to install the Template.
2. To Create a new Vazor project, write Vazor in the search box in the new project dialog and select the Vazor project type you want.
3. If there are any errors in the project, restor the NuGets. Open the NuGet Package manager Console:
Tools\NuGet Package manager Console\Package manager Console
Write the Command: 
dotnet restore
and click ENTER.
4. To add a Vazor View or page, from Project menu click Add New Item. You will find the Vazor items at the top of the items list.
5, Give us a feed back in the issues section in the project repo on GitHub.
https://github.com/VBAndCs/Vazor/issues
and please give the project a star.