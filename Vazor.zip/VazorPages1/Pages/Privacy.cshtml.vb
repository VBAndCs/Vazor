﻿Imports System
Imports System.Collections.Generic
Imports System.Linq
Imports System.Threading.Tasks
Imports Microsoft.AspNetCore.Mvc
Imports Microsoft.AspNetCore.Mvc.RazorPages

Public Class PrivacyModel : Inherits PageModel
    Public Sub OnGet()

    End Sub
End Class
