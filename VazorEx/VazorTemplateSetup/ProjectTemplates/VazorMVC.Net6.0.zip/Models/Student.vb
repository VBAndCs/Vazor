﻿Public Class Student
    Public Id As Integer
    Public Name As String
    Public Age As Integer
    Public Grade As Integer
End Class
